#include "affichage.h"
int obstacle(char a);
int partieSokoban(partie *game);