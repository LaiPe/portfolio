#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "struct.h"

void afficher_ascii_art(const char *nom_fichier);
void texte_encadre(const char * mot, int bande);
void printMenu();
void printTerrain(terrain *t);